﻿Le programme permet d'opérer rapidement le renommage des fichiers de tout type.
- Soit vous renommer les fichiers en numérique
- Soit vous modifier le nom alphanumérique déjà existant
		* En ajoutant avant ou après le nom du fichier
		* En insérant une chaine de caractères 
			à la position i
		* En effaçant une chaine de caractères  
		* En remplaçant une chaine de caractères 
			par une autre




